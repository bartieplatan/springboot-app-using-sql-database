package com.example.f1kotprog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class F1kotprogApplication {

    public static void main(String[] args) {
        SpringApplication.run(F1kotprogApplication.class, args);
    }

}
