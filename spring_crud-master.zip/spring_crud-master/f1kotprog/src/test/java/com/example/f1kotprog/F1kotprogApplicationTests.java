package com.example.f1kotprog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class F1kotprogApplicationTests {

	@Test
	void contextLoads() {
	}

}
